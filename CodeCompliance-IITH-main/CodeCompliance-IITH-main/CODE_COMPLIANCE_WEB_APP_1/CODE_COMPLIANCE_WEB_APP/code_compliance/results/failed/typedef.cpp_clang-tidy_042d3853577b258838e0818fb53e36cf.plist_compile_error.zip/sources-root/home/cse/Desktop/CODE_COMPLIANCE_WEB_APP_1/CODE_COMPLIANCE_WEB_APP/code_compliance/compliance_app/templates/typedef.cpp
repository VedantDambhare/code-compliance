#include <bits/stdc++.h>
using namespace std;
 
int abc()
{
   
    typedef std::vector<int> vect; 
    vect v;
  
    v.push_back(100);
    v.push_back(200);

  
    for (auto X : v) {
        //cout << X << " ";
    }
  
    return 0;
}

