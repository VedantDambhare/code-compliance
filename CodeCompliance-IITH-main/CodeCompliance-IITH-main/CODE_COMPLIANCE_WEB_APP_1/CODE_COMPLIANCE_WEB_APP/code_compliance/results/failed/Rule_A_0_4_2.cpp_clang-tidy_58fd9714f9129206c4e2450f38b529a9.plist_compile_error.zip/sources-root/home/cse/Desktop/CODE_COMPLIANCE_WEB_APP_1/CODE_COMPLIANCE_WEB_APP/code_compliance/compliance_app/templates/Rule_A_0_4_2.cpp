class class1{
   long double  j1;
    void func2(){
        long double  j2;
    }

};