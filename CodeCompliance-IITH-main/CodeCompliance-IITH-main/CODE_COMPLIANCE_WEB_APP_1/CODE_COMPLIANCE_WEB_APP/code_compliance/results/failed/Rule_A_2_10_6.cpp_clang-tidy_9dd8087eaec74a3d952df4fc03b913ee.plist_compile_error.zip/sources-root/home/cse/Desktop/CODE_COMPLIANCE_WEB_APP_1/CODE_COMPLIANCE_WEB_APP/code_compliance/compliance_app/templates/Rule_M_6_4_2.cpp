class abc{
    void xyz(){
        int z=1,x=0;
        if(z==0){
            x++;

        }
        else if(z==1){
            x--;
        }
    }
};