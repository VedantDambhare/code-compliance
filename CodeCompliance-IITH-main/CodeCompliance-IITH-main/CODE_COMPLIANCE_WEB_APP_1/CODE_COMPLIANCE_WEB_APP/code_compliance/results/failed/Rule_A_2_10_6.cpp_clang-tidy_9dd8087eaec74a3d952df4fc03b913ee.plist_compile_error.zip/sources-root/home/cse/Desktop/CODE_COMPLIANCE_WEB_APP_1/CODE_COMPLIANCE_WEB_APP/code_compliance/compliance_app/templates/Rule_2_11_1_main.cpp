class c1{
    volatile int j1;
    void func1(){
        volatile int j2;
    }

};
int main(){}
