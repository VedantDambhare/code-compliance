void gen1(){};
char g2;
class gen1{};


namespace n2{
    
     class var4{

     };
     static int var2;
     int var3;
     static int var4;
    
};
namespace n1{
     static int num;
};