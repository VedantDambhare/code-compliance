#include<cstdint>
enum class enum1 : std::uint32_t
{
One,
Two=2,
Three

    
};