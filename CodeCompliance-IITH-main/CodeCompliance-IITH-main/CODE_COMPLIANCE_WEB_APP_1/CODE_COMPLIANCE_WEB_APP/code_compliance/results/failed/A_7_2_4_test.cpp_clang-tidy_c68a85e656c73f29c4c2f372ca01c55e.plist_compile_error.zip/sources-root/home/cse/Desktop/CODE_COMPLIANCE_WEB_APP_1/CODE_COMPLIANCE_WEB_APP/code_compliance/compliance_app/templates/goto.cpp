int main(){
    int a[10];
    label1:
    for (int i=1;i<10;i++){
       a[i]=1;

    }
    goto label1;
    label2:
    int i=0;
    while(i<50){
        a[i]=0;
    }
    goto label2;
}