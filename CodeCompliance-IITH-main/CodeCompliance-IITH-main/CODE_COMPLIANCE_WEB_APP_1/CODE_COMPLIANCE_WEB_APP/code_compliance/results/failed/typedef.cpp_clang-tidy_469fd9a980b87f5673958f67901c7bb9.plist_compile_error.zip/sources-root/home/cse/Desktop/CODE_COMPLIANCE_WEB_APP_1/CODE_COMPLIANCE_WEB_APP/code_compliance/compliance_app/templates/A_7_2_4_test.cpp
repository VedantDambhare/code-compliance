// #include<cstdint>
enum class enum1 
{
One,
Two=2,
Three

    
};
int main()
{
}
