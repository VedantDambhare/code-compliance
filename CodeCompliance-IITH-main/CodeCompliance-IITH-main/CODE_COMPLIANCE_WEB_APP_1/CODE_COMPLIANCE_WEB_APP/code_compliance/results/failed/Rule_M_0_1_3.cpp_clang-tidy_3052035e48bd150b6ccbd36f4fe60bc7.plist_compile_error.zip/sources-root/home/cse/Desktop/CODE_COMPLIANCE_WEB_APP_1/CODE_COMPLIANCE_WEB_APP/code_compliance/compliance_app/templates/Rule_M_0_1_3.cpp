class c1{
    void abc(){
        int x,y;
        int z;
        x++;
        y++;
    }
};